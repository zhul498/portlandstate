#include <stdio.h>

// gcc -Wall -o hello hello.c  <- cl command to compile hello.c
// ./hello <- cl command to execute it 

int main ( void )
{
	
	printf("Hello CS205\n");
	return 0;
}


